import bcrypt

print('bcrypt gensalt', bcrypt.gensalt())
